# Lecture 1: Introduction

Some intro text discussing vectors and matrices.

![](images/abc123.jpg)

More text discussing the figure above, including some math: $x^2 + y^2 = z^2$.

![](images/def456.jpg)

Text referencing the first figure again, further down the document:

![](images/abc123.jpg)

End of document.
